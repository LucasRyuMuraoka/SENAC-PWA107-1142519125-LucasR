import RouterApp from './Routes.js';

function App() {
  return(
    <div>
        <RouterApp/>
    </div>
  );
}

export default App;